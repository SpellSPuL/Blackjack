(c)2000-2026 Christopher Evans

Current Site -
novaroma.io/archive.html

This software is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (CC BY-NC-ND 4.0).

You may copy and redistribute this software in any medium or format for non-commercial purposes only, provided that you give appropriate credit, provide a link to the license, and indicate if any license notice was changed. You may not use the software for commercial purposes, and if you modify, transform, or build upon it, you may not distribute the modified material.

--------------------------------

It's a blackjack game that ran in a mame cabinet under DOS. It's been recompiled to run under modern versions of windows without sound.

Control Keys - 

5 - Add Coin
Left Arrow - Increase Bet
Right Arrow - Decrease Bet
Space - Deal
Up - Hit
Down - Stand
Esc - Exit Program